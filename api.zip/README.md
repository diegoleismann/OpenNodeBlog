# OpenNodeBlog

Node Express CMS Backend

Erro EADDRINUSE: Porta 3000 em USO

netstat -aon | findstr :3000
Taskkill /PID <pid> /F
